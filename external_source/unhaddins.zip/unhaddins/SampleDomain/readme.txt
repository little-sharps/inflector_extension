Chinook_Original is a sample domain that can work with the original Chinook database.

If you want to update a preexistent chinook database, you need to run:
	1-NhibernateChanges_For_Chinook.sql
	2-Remove_Duplicated_FK.sql

If you want a full chinook database with Hi/Lo, you need to run:
	1-FullChinookWithHilo.sql
	