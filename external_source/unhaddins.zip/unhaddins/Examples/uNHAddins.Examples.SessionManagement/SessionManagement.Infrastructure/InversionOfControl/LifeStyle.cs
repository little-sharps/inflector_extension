﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SessionManagement.Infrastructure.InversionOfControl
{
	public enum LifeStyle
	{
		Transient, 
		Singleton
	}
}
