namespace uNhAddIns.Example.MonoRailConversationUsage.DatabaseAccessObjects {
    public interface IEntity : IEntityWithTypeId<int> {
    }
}