namespace uNhAddIns.Example.MonoRailConversationUsage.DatabaseAccessObjects {
    public interface IDao<TEntity> : IDaoWithTypeId<TEntity, int> {
    }
    

}