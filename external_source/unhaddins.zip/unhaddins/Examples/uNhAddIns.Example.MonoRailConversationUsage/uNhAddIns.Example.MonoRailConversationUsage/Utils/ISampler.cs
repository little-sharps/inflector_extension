using uNhAddIns.Example.MonoRailConversationUsage.Entities;

namespace uNhAddIns.Example.MonoRailConversationUsage.Utils {
    public interface ISampler   {
        Category CreateSampleCategory();
    }
}