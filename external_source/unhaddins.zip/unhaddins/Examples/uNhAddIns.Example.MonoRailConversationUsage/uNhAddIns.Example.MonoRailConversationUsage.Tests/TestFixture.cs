﻿namespace uNhAddIns.Example.MonoRailConversationUsage.Tests {
    public class TestFixture {
    // TODO: :-)
    }
}
