1) Create database (script\create database.sql)
2) Change database connection string (\uNhAddIns.Example.MonoRailConversationUsage\hibernate.cfg.xml ) 
3) deploy web application (IIS) or start from the visual studio, all tables will created on starting