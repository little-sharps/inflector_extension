
using uNhAddIns.Example.AspNetMVCConversationUsage.Entities;

namespace uNhAddIns.Example.AspNetMVCConversationUsage.Utils
{
    public interface ISampler   {
        Category CreateSampleCategory();
    }
}