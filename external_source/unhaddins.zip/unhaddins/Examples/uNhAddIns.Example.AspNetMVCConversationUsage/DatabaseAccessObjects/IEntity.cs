
namespace uNhAddIns.Example.AspNetMVCConversationUsage.DatabaseAccessObjects
{
    public interface IEntity : IEntityWithTypeId<int> 
    {
    
    }
}