namespace uNhAddIns.Example.AspNetMVCConversationUsage.DatabaseAccessObjects
{
    public interface IDao<TEntity> : IDaoWithTypeId<TEntity, int> {
    }
    

}