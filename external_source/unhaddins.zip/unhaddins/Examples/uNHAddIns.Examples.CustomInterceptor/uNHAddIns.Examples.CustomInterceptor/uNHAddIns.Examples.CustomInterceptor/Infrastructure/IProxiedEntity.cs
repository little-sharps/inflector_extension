namespace uNHAddIns.Examples.CustomInterceptor.Infrastructure
{
    public interface IProxiedEntity
    {
        string EntityName { get; }
    }
}