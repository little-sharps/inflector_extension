﻿using System;
using uNhAddIns.Entities;

namespace ChinookMediaManager.Domain
{
    public class Genre : Entity
    {
        public virtual string Name { get; set; }
    }
}