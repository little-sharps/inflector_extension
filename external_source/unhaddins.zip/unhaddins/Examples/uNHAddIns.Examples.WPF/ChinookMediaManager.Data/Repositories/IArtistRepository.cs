using ChinookMediaManager.Domain;

namespace ChinookMediaManager.Data.Repositories
{
    public interface IArtistRepository : IRepository<Artist>
    {}
}