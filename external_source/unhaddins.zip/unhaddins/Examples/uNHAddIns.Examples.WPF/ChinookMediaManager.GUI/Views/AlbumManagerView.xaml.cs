﻿using System.Windows;

namespace ChinookMediaManager.GUI.Views
{
    /// <summary>
    /// Lógica de interacción para AlbumManagerView.xaml
    /// </summary>
    public partial class AlbumManagerView : Window
    {
        public AlbumManagerView()
        {
            InitializeComponent();
        }
    }
}