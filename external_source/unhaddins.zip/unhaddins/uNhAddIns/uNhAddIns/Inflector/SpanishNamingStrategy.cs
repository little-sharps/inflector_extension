namespace uNhAddIns.Inflector
{
	public class SpanishNamingStrategy : InflectorNamingStrategy
	{
		public SpanishNamingStrategy() : base(new SpanishInflector()) {}
	}
}