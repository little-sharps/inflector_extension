namespace uNhAddIns.Inflector
{
	public interface IRuleApplier
	{
		string Apply(string word);
	}
}