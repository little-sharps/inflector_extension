namespace uNhAddIns.Inflector
{
	public class EnglishNamingStrategy : InflectorNamingStrategy
	{
		public EnglishNamingStrategy() : base(new EnglishInflector()) {}
	}
}